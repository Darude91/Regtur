# 📺 Kijkdoos — IPTV voor Android, Android TV, Windows en web

Gratis films, series en live tv op één plek, plus je eigen IPTV-abonnementen.
Alleen streams die echt werken worden getoond; de rest blijft verborgen (aan te zetten via ⚙).

**Web-versie:** https://endless1977.github.io/IpTv/
**Downloads (Android .apk / Windows .exe):** [Releases → latest](https://github.com/Endless1977/IpTv/releases/latest)

## Wat zit erin
- **Films** en **Series** (en **Live TV** zodra er zenders zijn), Netflix-achtige rijen met thumbnails
- **Gratis bronnen:**
  - Internet Archive — duizenden rechtenvrije speelfilms, tv-series en tekenfilms (on demand)
  - iptv-org — openbaar beschikbare film-, serie-, klassieke en animatiekanalen + Nederlandse zenders
- **Abonnementen:** Xtream Codes (server + gebruikersnaam + wachtwoord) of een M3U-link.
  Films, series (met seizoenen/afleveringen) en zenders worden automatisch ingedeeld.
  Een verlopen of niet-werkend abonnement toont niets.
- **Beschikbaarheidscheck:** elke stream wordt op de achtergrond getest; resultaten worden 6 uur onthouden.
- Zoeken, detailpagina's, automatisch volgende aflevering, "Kopieer link" voor VLC.

## Installeren
| Platform | Hoe |
|---|---|
| Android (telefoon) | Download `Kijkdoos.apk` uit Releases en installeer (onbekende bronnen toestaan) |
| Android TV | Dezelfde `Kijkdoos.apk`. Zet hem op je TV met de app *Downloader* (voer de release-link in) of *Send Files to TV*. Kijkdoos verschijnt op het startscherm en schakelt zelf over naar TV-modus |
| Windows | `Kijkdoos-Setup-x.exe` of de portable `.exe` uit Releases |
| Beide (lichtgewicht) | Open de web-versie in Chrome/Edge → *Installeren* / *Toevoegen aan startscherm* |

De Android- en Windows-app hebben geen browserbeperkingen (CORS, http-streams) en tonen dus meer zenders dan de web-versie.

## Bediening met afstandsbediening (Android TV)
- Pijltjes: navigeren · OK: openen/afspelen/pauzeren · Terug: een stap terug
- In de speler: ◀ ▶ = 10 s terug/vooruit, mediatoetsen werken ook (volgende/vorige aflevering)
- TV-modus is automatisch; handmatig te zetten via ⚙ → TV-modus

## Categorieën
Klap je een categorie open (**Alles ›**), dan zie je *alle* titels daarvan; het raster laadt tijdens het scrollen steeds meer bij.
Titels waarvan al bekend is dat ze niet werken blijven verborgen (⚙ → toon ook onbeschikbare om ze toch te zien).

## Web-versie met proxy (optioneel)
Veel IPTV-servers blokkeren browsers. Draai `python3 proxy.py` (bijv. op een Raspberry Pi) en
open `http://<pi-ip>:8090/`, of vul `http://<pi-ip>:8090/proxy?url=` in bij ⚙ → CORS-proxy.

## Zelf bouwen
Elke push naar `main` bouwt via GitHub Actions automatisch de web-versie (Pages), de APK en de EXE.
Lokaal: `npm install && npm start` (Windows-app) of `npx cap add android && npx cap sync && npx cap open android`.

> Kijkdoos levert zelf geen content; het speelt openbare gratis streams en jouw eigen abonnementen af.
